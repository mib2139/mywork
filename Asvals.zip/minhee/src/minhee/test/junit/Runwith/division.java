package minhee.test.junit.Runwith;

import org.junit.Test;

public class division {
	
	@Test
	public void division() {
		int inputNum1 = 40;
		int inputNum2 = 4;
		int sum = inputNum1/inputNum2;
		System.out.println("inputNum1/inputNum2 = "+sum);
	} 
}
