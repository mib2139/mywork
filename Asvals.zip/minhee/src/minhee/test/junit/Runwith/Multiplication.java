package minhee.test.junit.Runwith;

import org.junit.Test;

public class Multiplication {
	
	@Test
	public void Multiplication() {
		int inputNum1 = 6;
		int inputNum2 = 4;
		int sum = inputNum1*inputNum2;
		System.out.println("inputNum1*inputNum2 = "+sum);
	} 
}
