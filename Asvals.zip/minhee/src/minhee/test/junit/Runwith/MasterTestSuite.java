package minhee.test.junit.Runwith;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({Addition.class, Substraction.class, Multiplication.class,division.class})
public class MasterTestSuite {
	
}
