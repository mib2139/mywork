package minhee.test.junit;

public class Calculator {

	public int Addition(int inputnum1, int inputNum2) {
		return inputnum1+inputNum2;
	}
	
	public int subtract(int inputnum1, int inputNum2) {
		return inputnum1-inputNum2;
	}
	
	public int multiplication(int inputnum1, int inputNum2) {
		return inputnum1*inputNum2;
	}
	
	public int division(int inputnum1, int inputNum2) {
		return inputnum1/inputNum2;
	}
	
}
