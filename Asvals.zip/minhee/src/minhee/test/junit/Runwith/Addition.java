package minhee.test.junit.Runwith;

import org.junit.Test;

public class Addition {
	
	@Test
	public void Addition() {
		int inputNum1 = 6;
		int inputNum2 = 4;
		int sum = inputNum1+inputNum2;
		System.out.println("inputNum1+inputNum2 = "+sum);
	}
}
