package minhee.test.junit;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculatorTest {
	@Test
	public void testAdder() {
		Calculator calculator = new Calculator();
		assertEquals(30, calculator.Addition(10, 20));
	}
	
	
	@Test
	public void testMinus() {
		Calculator calculator = new Calculator();
		assertEquals(15, calculator.subtract(20, 5));
	}

	@Test
	public void testMultiple() {
		Calculator calculator = new Calculator();
		assertEquals(63, calculator.multiplication(7, 9));
	}
	
	@Test
	public void testDivision() {
		Calculator calculator = new Calculator();
		assertEquals(10, calculator.division(30, 3));
	}

}
